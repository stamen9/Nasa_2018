﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundLooper : MonoBehaviour {
	public GameObject BG1;
	public GameObject BG2;

	public EventHandler paouse;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		if (!paouse.paouseBG) {

			if (BG1.transform.position.x <= -19.661) {
				Debug.Log (BG1.transform.position.x);
				BG1.transform.Translate (new Vector3 (2 * 19.66f, 0, 0));
			}
			if (BG2.transform.position.x <= -19.661) {
				BG2.transform.Translate (new Vector3 (2 * 19.66f, 0, 0));
			}
			BG1.transform.position += Vector3.left * Time.deltaTime;
			BG2.transform.position += Vector3.left * Time.deltaTime;

		}
	}
}
