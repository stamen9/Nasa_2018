﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CanvasUtilities : MonoBehaviour {

	public GameObject BasePanel1;
	public GameObject BasePanel2;
	public GameObject BasePanel3;
	public GameObject BasePanel4;

	public GameObject BaseCanvas;
	public GameObject ExpeditionCanvas;
	public GameObject MissionCanvas;
	public GameObject BackgroundLooper;

	public GameObject ProvisionPanel;
	public GameObject MissionInfoPanel;

	public GameObject warrninPanel;

	public MissionController MissionController;

	public void CloseWarrning()
	{
		warrninPanel.SetActive (false);
	}

	public void EndMission()
	{
		MissionCanvas.SetActive (false);
		BackgroundLooper.SetActive (false);
		BaseCanvas.SetActive (true);

	}
	//START MISSION
	public void StartMission()
	{


		/*MissionCanvas.SetActive (true);
		MissionCanvas.GetComponent<EventHandler>().missionUpdater (MissionController.missionContainer[MissionController.lastSelectedMission]);
		BackgroundLooper.SetActive (true);
		ExpeditionCanvas.SetActive (false);*/
	}

	//OPEN MISSIONINFOPANEL
	public void OpenMissionInfoPanel()
	{
		MissionInfoPanel.SetActive (true);
	}

	//CLOSE MISSIONINFOPANEL
	public void CloseMissionInfoPanel()
	{
		MissionInfoPanel.SetActive (false);
	}


	//CLOSE PROVISIONPANEL
	public void CloseProvisionPanel()
	{
		ProvisionPanel.SetActive (false);
		MissionInfoPanel.SetActive (true);
	}

	//OPEN PROVISIONPANEL
	public void OpenProvisionPanel()
	{
		ProvisionPanel.SetActive (true);
		MissionInfoPanel.SetActive (false);
	}


	//CLOSE EXPEDITIONCANVAS & OPEN BASECANVAS
	public void OpenBaseCanvas()
	{
		BaseCanvas.SetActive (true);
		ExpeditionCanvas.SetActive (false);
	}


	//CLOSE BASECANVAS & OPEN EXPEDITIONCANVAS
	public void OpenExpeditionCanvas()
	{
		ExpeditionCanvas.SetActive (true);
		BaseCanvas.SetActive (false);
	}



	//OPEN BASE PANESL
	public void OpenBasePanel1()
	{
		BasePanel1.SetActive (true);
	}
	public void OpenBasePanel2()
	{
		BasePanel2.SetActive (true);
	}
	public void OpenBasePanel3()
	{
		BasePanel3.SetActive (true);
	}
	public void OpenBasePanel4()
	{
		BasePanel4.SetActive (true);
	}

	//CLOSE BASE PANELS
	public void CloseBasePanel1()
	{
		BasePanel1.SetActive (false);
	}
	public void CloseBasePanel2()
	{
		BasePanel2.SetActive (false);
	}
	public void CloseBasePanel3()
	{
		BasePanel3.SetActive (false);
	}
	public void CloseBasePanel4()
	{
		BasePanel4.SetActive (false);
	}

}
