﻿using System;
using System.Collections.Generic;

namespace AssemblyCSharp
{
	[Serializable]
	public class DialogueEncounter
	{
		public List<DialogueScreen> dialogueScreens;
		public List<DialogueEnding> endings;
	}	
}

