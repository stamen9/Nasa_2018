﻿using System;
using System.IO;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

namespace AssemblyCSharp
{
	public class DialogueEncounterController : MonoBehaviour
	{
		public GameObject dialoguePanel;
		public Transform effectText;


		const int ENDING_BUTTON_INDEX = 5;
		const string PATH = "Assets/DialogueEncounters";
		static System.Random rnd =new System.Random();
		DialogueEncounter dialogueEncounter;
		DialogueScreen curDialogueScreen;



		public int[] returnChange = new int[3];

		public DialogueEncounterController (int encounterId=0)
		{
			int encounterCount = Directory.GetFiles (PATH, "*.json", SearchOption.TopDirectoryOnly).Length;
			//int encounterId = rnd.Next (0, encounterCount);
			string fileName = Directory.GetFiles (PATH, "*.json", SearchOption.TopDirectoryOnly) [encounterId];

			string dialogueJSON = File.ReadAllText(fileName);
			Debug.Log (dialogueJSON);
				
			dialogueEncounter = JsonUtility.FromJson<DialogueEncounter> (dialogueJSON);
		}

		public void visualiseDialoguePanel(){
			dialoguePanel.SetActive (true);
		}

		public void startDialogue(){
			visualiseDialoguePanel ();
			curDialogueScreen = dialogueEncounter.dialogueScreens [0];
			dialoguePanel.transform.GetChild (ENDING_BUTTON_INDEX).gameObject.SetActive (false); 
			updateGameObjects ();

		}

		public void proceedDialogue(int index){


			string effect = curDialogueScreen.options[index].next;

			if (effect [0] == 'E') {
				endDialogue (Int32.Parse (effect.Substring (1)));

			}
			else {
				curDialogueScreen = dialogueEncounter.dialogueScreens [Int32.Parse (effect)];
				updateGameObjects ();
			}
		}

		public void endDialogue(int endingNum){
			
			updateResources(dialogueEncounter.endings[endingNum].effects);
			for (int buttonIndex = 0; buttonIndex < 4; buttonIndex++) {
				Debug.Log (dialoguePanel.transform.GetChild (buttonIndex + 1));
				dialoguePanel.transform.GetChild (buttonIndex + 1).gameObject.SetActive (false); 
			}
			dialoguePanel.transform.GetChild (ENDING_BUTTON_INDEX).gameObject.SetActive (true); 

		}

		public void updateGameObjects(){

			dialoguePanel.transform.GetChild(0).GetComponent<Text> ().text = curDialogueScreen.description;
			for (int i = 0; i < curDialogueScreen.options.Count; i++) {

				dialoguePanel.transform.GetChild (i + 1).GetChild(0).GetComponent<Text> ().text = curDialogueScreen.options [i].response;
				dialoguePanel.transform.GetChild (i + 1).gameObject.SetActive (true); 
			}
			for (int i = curDialogueScreen.options.Count; i < 4; i++) {
				//Debug.Log (i + 1);
				dialoguePanel.transform.GetChild (i + 1).gameObject.SetActive (false); 
			}
		}

		public void updateResources(List<DialogueEndingEffect> effects){
		
			Debug.Log (effects.Count + " effect count");
			//if(string.IsNullOrEmpty(effects[0].t
			for (int i = 0; i < effects.Count; i++) {
				Transform temp = Instantiate (effectText, new Vector3 (0,0, 0), Quaternion.identity);
				temp.localScale = new Vector3((1f/108f),(1f/108f),(1f/108f));

				temp.position = new Vector3 (0,-0.3f + (-i/4f),0);
				temp.SetParent (dialoguePanel.transform);

				temp.GetComponent<Text> ().text = effects [i].type + " " + effects [i].modifier;
				if (effects [i].type.Equals ("food")) {
					returnChange [0] = effects [i].modifier;
				} else if (effects [i].type.Equals ("dogs")) {
					returnChange[1] = effects [i].modifier;
				} else if (effects [i].type.Equals ("medicine")) {
					returnChange[2] = effects [i].modifier;
				}

			}

		}

		public int[] closeDialogueWindow() {
			


			GameObject[] TextCloneColector = GameObject.FindGameObjectsWithTag("DeletableText");
			Debug.Log ( GameObject.FindGameObjectsWithTag("DeletableText").Length);
			foreach (GameObject del in TextCloneColector) {
				Destroy (del);
			}

			dialoguePanel.SetActive (false);

			return returnChange;
		}
	}
}

