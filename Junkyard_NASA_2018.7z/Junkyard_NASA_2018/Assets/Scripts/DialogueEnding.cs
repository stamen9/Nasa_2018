﻿using System;
using System.Collections.Generic;

namespace AssemblyCSharp
{
	[Serializable]
	public class DialogueEnding
	{
		public List<DialogueEndingEffect> effects;
	}
}

