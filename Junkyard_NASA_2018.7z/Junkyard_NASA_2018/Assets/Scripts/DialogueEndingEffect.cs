﻿using System;

namespace AssemblyCSharp
{
	[Serializable]
	public class DialogueEndingEffect
	{
		public string type;
		public int modifier;
	}
}

