﻿using System;

namespace AssemblyCSharp
{
	[Serializable]
	public class DialogueOption
	{
		public string response;
		public string next;
	}
}

