﻿using System;
using System.Collections.Generic;

namespace AssemblyCSharp
{
	[Serializable]
	public class DialogueScreen
	{
		public string description;
		public List<DialogueOption> options;
	}
}

