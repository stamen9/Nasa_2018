﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventHandler : MonoBehaviour {
	public bool isTimePaused = false;
	public Stack<AssemblyCSharp.DialogueEncounterController> encounterStack = new Stack<AssemblyCSharp.DialogueEncounterController>();

	public AssemblyCSharp.DialogueEncounterController currentEncounter;


	public int encounterNum;
	public int missionLength;
	public float missionStartTime;
	public float missionEncounterGap;


	public bool paouseBG = false;

	public MissionResourcManager MRM;

	public GameObject dialoguePanel;
	public Transform effectText;

	bool needToFillStack = false;

	public void missionUpdater (Mission missionDetails){
		this.encounterNum = missionDetails.encounters;
		this.missionLength = missionDetails.len;
	}
		

	// Use this for initialization
	void Start () {

		for (int i = 0; i < 3; i++) {

			AssemblyCSharp.DialogueEncounterController newEnc = new AssemblyCSharp.DialogueEncounterController (2-i);

			encounterStack.Push (newEnc);
		}

		missionStartTime = Time.deltaTime;
	}
	void OnEnable()
	{
		AssemblyCSharp.DialogueEncounterController newEnc = new AssemblyCSharp.DialogueEncounterController ();

		encounterStack.Push (newEnc);
	}
	
	// Update is called once per frame
	void Update () {
		if (encounterStack.Count == 0) {
			MRM.ReturnResourcesToTown ();

			GameObject.Find ("PanelControler").GetComponent<CanvasUtilities>().EndMission();
			Debug.Log("stack is empty");

			missionStartTime = 0f;
			return;
		}
		missionStartTime += Time.deltaTime / 2f;
		if (!isTimePaused &&  missionEncounterGap < missionStartTime) {

			Debug.Log("DIALOG ENCOUNTER!!!!!!!!!!!!!!!!!!!");
			isTimePaused = true;

			currentEncounter = encounterStack.Pop();
			currentEncounter.dialoguePanel = dialoguePanel;
			currentEncounter.effectText = effectText;
			currentEncounter.startDialogue ();
			paouseBG = true;

		}
	}

	public void CallProceedtDialogue(int id)
	{
		currentEncounter.proceedDialogue (id);
	}
	public void CallCloseDialogueWindow()
	{
		int[] result = currentEncounter.closeDialogueWindow ();
		paouseBG = false;
		MRM.food += result [0];
		MRM.dogs += result [1];
		MRM.medicine += result [2];
		isTimePaused = false;
		missionStartTime = 0f;
	}
		
}
