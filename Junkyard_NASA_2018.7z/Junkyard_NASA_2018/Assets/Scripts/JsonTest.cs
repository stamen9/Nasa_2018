﻿using System;

namespace AssemblyCSharp
{
	[Serializable]
	public class JsonTest
	{
		public int dialogueScreens;
		public int adas;
	}
}

