﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;
using UnityEngine;
 

public class Mission {

	public int len;
	public int encounters;
	public string description;
	static System.Random rnd =new System.Random();
	public enum Teren {EASY=1, NORMAL=2, DIFFICULT=3};
	public Teren teren;
	public Mission(string fileName)
	{
		string content = File.ReadAllText(String.Format("./Assets/MissionDescriptionContainer/{0}.json",fileName));
		MissionSerializer ms = JsonUtility.FromJson<MissionSerializer> (content);
		this.description = ms.description;
		this.len =(int) ms.len;
		
		this.teren = (Teren)(rnd.Next(1,4));
		this.encounters = 666;
	}

	public void CalcEnc(int weather) //based on len and teren
	{
		//-17 -38
		int weatherDiff = 0;
		if(weather < -38){
			weatherDiff = 2;
		}else if(weather < -17)
		{
			weatherDiff = 1;
		}
		
		int lenDiff = 0;
		if (this.len < 5)
		{
			lenDiff = 0;
		}
		else if(this.len < 15)
		{
			lenDiff =1;
		}
		else
		{
			lenDiff = 2;
		}
		int diff = weatherDiff + (int)this.teren + lenDiff;
		this.encounters = rnd.Next(diff-2,diff+2);
	}

	public int getLen()
	{
		return this.len;
	}

	public void setLen(int len)
	{
		this.len = len;
	}

	public int getEncounters()
	{
		return this.encounters;
	}

	public void setEncounters(int encounters)
	{
		this.encounters = encounters;
	}

}
