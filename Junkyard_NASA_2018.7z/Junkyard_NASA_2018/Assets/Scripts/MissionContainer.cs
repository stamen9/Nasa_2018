﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissionContainer : MonoBehaviour {

	public Mission[] missionContainer = new Mission[5];
	public GameObject MissionPanel;
	// Use this for initialization
	void Start () {
		for (int i = 0; i < 5; i++) {
			missionContainer [i] = new Mission("gosho");
		}
		for (int i = 0; i < 5; i++) {
			//Debug.Log(missionContainer [i].diff );
		}

	}

	public void SetMission(int i)
	{
		
	}

	// Update is called once per frame
	void Update () {
		
	}
}
