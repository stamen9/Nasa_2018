﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MissionController : MonoBehaviour {

	public Mission[] missionContainer = new Mission[5];
	// Use this for initialization

	public int lastSelectedMission;
	public WeatherTime weatherTime;

	public GameObject MissionTextContainer;

	void Start () {
		for (int i = 0; i < 5; i++) {
			string fileName = "Mission" + (i+1);
			missionContainer [i] = new Mission(fileName);
		}
		for (int i = 0; i < 5; i++) {
			Debug.Log(missionContainer [i].len);
		}
		AssemblyCSharp.DialogueEncounterController enc = new AssemblyCSharp.DialogueEncounterController ();

	}
	public void setEncounters()
	{
		missionContainer[lastSelectedMission].setEncounters((int)weatherTime.GetNextTemp());
	}
	public void SetDescription(int i)
	{
		lastSelectedMission = i;

		Debug.Log (MissionTextContainer.transform.childCount);
		MissionTextContainer.transform.GetChild(0).GetComponent<Text>().text = missionContainer[i].description;

		Debug.Log (missionContainer.Length);
		Debug.Log (missionContainer[i].len);
		Debug.Log (missionContainer[i].description);
		MissionTextContainer.transform.GetChild(1).GetComponent<Text>().text = "Length:" + (int)missionContainer[i].len + "km";
		MissionTextContainer.transform.GetChild(2).GetComponent<Text>().text = "Temperature:"+weatherTime.GetNextTemp()+"C";
	}

	// Update is called once per frame
	void Update () {
		
	}
}
