﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MissionResourcManager : MonoBehaviour {
	public int food;
	public int dogs;
	public int maxCap;
	public int curCap;
	public int medicine;
	public int sledCount;
	public Sled[] sleds = new Sled[5];

	public GameObject ExpeditionCanvas;
	public GameObject MissionCanvas;
	public GameObject BackgroundLooper;

	public GameObject overCapWarrinig;

	public MissionController MissionController;

	public GameObject ProvisionPanel;



	public Town town;

	public void ModifyDogs(Slider slider)
	{
		dogs = (int)slider.value;
	}
	public void ModifyFood(Slider slider)
	{
		food = (int)slider.value;
	}

	public void ModifySleds(Slider slider)
	{
		sledCount = (int)slider.value;
	}
	public void ModifyMedicine(Slider slider)
	{
		medicine = (int)slider.value;
	}
	// Use this for initialization

	public void StartMission()
	{


		GameObject.Find ("FoodSlider").GetComponent<Slider>().value = GameObject.Find ("FoodSlider").GetComponent<Slider>().minValue;

		GameObject.Find ("DogSlider").GetComponent<Slider>().value = GameObject.Find ("DogSlider").GetComponent<Slider>().minValue;

		GameObject.Find ("MedicineSlider").GetComponent<Slider>().value = GameObject.Find ("MedicineSlider").GetComponent<Slider>().minValue;

		GameObject.Find ("SledsSlider").GetComponent<Slider>().value = GameObject.Find ("SledsSlider").GetComponent<Slider>().minValue;

		MissionController.setEncounters();

		MissionCanvas.SetActive (true);
		MissionCanvas.GetComponent<EventHandler>().missionUpdater (MissionController.missionContainer[MissionController.lastSelectedMission]);
		BackgroundLooper.SetActive (true);
		ExpeditionCanvas.SetActive (false);



		//this.gameObject.SetActive (false);

	}


	void Start () {



		GameObject.Find ("FoodSlider").GetComponent<Slider>().maxValue = town.food;

		GameObject.Find ("DogSlider").GetComponent<Slider>().maxValue = town.dogs;

		GameObject.Find ("MedicineSlider").GetComponent<Slider>().maxValue = town.medicine;

		GameObject.Find ("SledsSlider").GetComponent<Slider>().maxValue = 5;
	}

	public void GetResourcesFromTown()
	{
		curCap = medicine * 2 + food;
		maxCap = sledCount * 100;

		if (curCap > maxCap) {

			overCapWarrinig.SetActive (true);
			return;
		}

		town.food -= food;
		town.dogs -= dogs;
		town.medicine -= medicine;

		StartMission ();
	}
	public void ReturnResourcesToTown()
	{
		town.food += food;
		town.dogs += dogs;
		town.medicine += medicine;
	}
	// Update is called once per frame
	void Update () {
		
	}
}
