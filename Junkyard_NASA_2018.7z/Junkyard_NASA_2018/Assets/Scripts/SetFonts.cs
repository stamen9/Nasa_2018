﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SetFonts : MonoBehaviour {

	public Font font;

	// Use this for initialization
	void Start () {
		var TextCon = FindObjectsOfType<Text>();
		Debug.Log (TextCon);
		foreach (var text in TextCon) {
			text.font = font;
			text.fontSize = 22;
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
