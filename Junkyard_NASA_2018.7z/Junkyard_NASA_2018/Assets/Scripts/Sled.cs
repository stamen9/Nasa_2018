﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sled {

	public const int MAX_DOGS = 6;
    public const int MIN_DOGS = 3;

    public int currDogs;
    public int dmg;
    public int cap;

    public Sled(int currDogs, int dmg, int cap)
    {
        this.currDogs = currDogs;
        this.dmg = dmg;
        this.cap = cap;
    }

	public int getCurrdogs()
	{
		return this.currDogs;
	}

	public void setCurrdogs(int currDogs)
	{
		this.currDogs = currDogs;
	}

	public int getDmg()
	{
		return this.dmg;
	}

	public void setDmg(int dmg)
	{
		this.dmg = dmg;
	}

	public int getCap()
	{
		return this.cap;
	}

	public void setCap(int cap)
	{
		this.cap = cap;
	}

}
