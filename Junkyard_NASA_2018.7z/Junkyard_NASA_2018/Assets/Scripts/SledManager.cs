﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SledManager : MonoBehaviour {


	public Text sledName;
	public Town town;
	public Text currHP;
	public Text nextHP;
	public Text currCap;
	public Text nextCap;
	public Text currDog;
	public Text nextDog;

	public int currentSled;


	public void setSledI(int i)
	{
		currentSled = i;
		sledName.name = "Sled " + i;
		currHP.text = "" + town.sleds2 [i].dmg;
		nextHP.text = "" +  (town.sleds2 [i].dmg + 1);
		currCap.text ="" +  town.sleds2 [i].cap;
		nextCap.text ="" +  (town.sleds2 [i].cap + 10);
	}

	public void UpCurrentHP ()
	{
		town.sleds2 [currentSled].dmg += 1;
		currHP.text = "" + town.sleds2 [currentSled].dmg;
		nextHP.text = "" +  (town.sleds2 [currentSled].dmg + 1);
	}


	public void UpCurrentCap ()
	{
		town.sleds2 [currentSled].cap += 10;
		currCap.text ="" +  town.sleds2 [currentSled].cap;
		currCap.text ="" +  (town.sleds2 [currentSled].cap + 10);
	}


	public void UpCurrentDog ()
	{
		;
	}
	// Use this for initialization
	void Start () {
		setSledI (0);
	}

	// Update is called once per frame
	void Update () {

	}
}
