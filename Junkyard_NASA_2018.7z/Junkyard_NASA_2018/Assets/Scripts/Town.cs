using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Town: MonoBehaviour{

    public int food;
    public int dogs;
    public int sleds;
    public int medicine;


	public Sled[] sleds2 = new Sled[5];
    public Town() { }

	void Start()
	{
		for (int i = 0; i < 5; i++) {
			sleds2 [i] = new Sled (0, 10, 100);
		}

	}

}