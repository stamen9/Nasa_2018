﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.IO;
using UnityEngine.UI;


public class WeatherTime : MonoBehaviour {

	public string fileName = "./Assets/DialogueEncounters/Weather/all.json";
	public List<double> temp;
	public int index;

	// Use this for initialization
	void Start () {
		temp = new List<double>();
		string jsonString = File.ReadAllText(fileName);
		TimeSerializer  ts = JsonUtility.FromJson<TimeSerializer>(jsonString);
		for(int i =0; i < ts.timeArr.Count; i++){
			for(int j = 0; j < ts.timeArr[i].array.Count; j++){
				temp.Add(ts.timeArr[i].array[j]);
			}
		}
		this.index = 0;
	}

	public double GetNextTemp(){
		double res = temp[index];
		index++;
		index = index % temp.Count;
		return res;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
